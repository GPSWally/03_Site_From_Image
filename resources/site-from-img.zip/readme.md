Give the students access to just the screenshot.jpg. Have them recreate the website from that image.
